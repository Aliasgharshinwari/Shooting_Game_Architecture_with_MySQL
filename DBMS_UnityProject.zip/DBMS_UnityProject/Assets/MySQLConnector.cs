using UnityEngine;
using MySql.Data.MySqlClient;
using System;

public class MySQLConnector : MonoBehaviour
{
    private string server = "localhost";
    private string database = "shooting_game";
    private string user = "root";
    private string password = "";
    private string connectionString;
    private MySqlConnection dbConnection;

    void Start()
    {
        connectionString = $"Server={server};Database={database};User ID={user};Password={password};";
        dbConnection = new MySqlConnection(connectionString);

        try
        {
            dbConnection.Open();
            Debug.Log("Database connection successful!");

            string query = "SELECT * FROM player";
            MySqlCommand cmd = new MySqlCommand(query, dbConnection);
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                Debug.Log("ID: " + dataReader["player_id"] + " Name: " + dataReader["player_name"] + " Currency: " + dataReader["currency"]);
            }

            dataReader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error: " + ex.Message);
        }
        finally
        {
            dbConnection.Close();
        }
    }
}

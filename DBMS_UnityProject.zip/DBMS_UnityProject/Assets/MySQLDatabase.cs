using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using UnityEngine;

public class MySQLDatabase{
    protected MySqlConnection connection;
    public MySQLDatabase(string connectionString){
        connection = new MySqlConnection(connectionString);
    }

    public void OpenConnection() {
        try{
            connection.Open();
            Debug.Log("Database connection opened.");
        }
        catch (Exception ex){
            Debug.LogError("Error opening database connection: " + ex.Message);
        }
    }

    public void CloseConnection(){
        try {
            connection.Close();
            Debug.Log("Database connection closed.");
        }
        catch (Exception ex){
            Debug.LogError("Error closing database connection: " + ex.Message);
        }
    }
    public List<Player> GetPlayers()
    {
        List<Player> players = new List<Player>();

        string query = "SELECT * FROM player";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Player player = new Player
                {
                    playerId = reader.GetInt32("player_id"),
                    playerName = reader.GetString("player_name"),
                    currency = reader.GetInt32("currency"),
                    numberOfKills = reader.GetInt32("number_of_kills"),
                    activeQuestId = reader.GetInt32("active_quest_id"),
                    selectedCharId = reader.GetInt32("selected_char_id")
                };
                players.Add(player);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading players from database: " + ex.Message);
        }

        return players;
    }
    public void AddPlayer(Player player){
        Debug.Log($"{player.playerId}");
        string query = $"INSERT INTO player( player_id , player_name , currency ,number_of_kills , active_quest_id, selected_char_id) VALUES( {player.playerId}, {player.playerName}, {player.currency}, {player.numberOfKills}, {player.activeQuestId}, ${player.selectedCharId});";
        MySqlCommand cmd = new MySqlCommand(query, connection);
        
        try
        {
            cmd.ExecuteNonQuery();
            Debug.Log("Successfully Added Player");
        }
        catch (Exception ex)
        {
            Debug.LogError("Error adding player to the database: " + ex.Message);
        }
        finally
        {
            connection.Close();
        }


    }
    
    public List<Weapon> GetWeapons()
    {
        List<Weapon> weapons = new List<Weapon>();

        string query = "SELECT * FROM weapon";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Weapon weapon = new Weapon
                {
                    weaponId = reader.GetInt32("weapon_id"),
                    weaponName = reader.GetString("name"),
                    damage = reader.GetInt32("damage"),
                    storeId = reader.GetInt32("store_id"),
                };
                weapons.Add(weapon);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading weapons from database: " + ex.Message);
        }

        return weapons;
    }
    public List<Quest> GetQuests()
    {
        List<Quest> quests = new List<Quest>();

        string query = "SELECT * FROM quest";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Quest quest = new Quest
                {
                    questId = reader.GetInt32("quest_id"),
                    questName = reader.GetString("quest_name"),
                    reward = reader.GetInt32("reward"),
                    questType = reader.GetString("quest_type"),
                };
                quests.Add(quest);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading quests from database: " + ex.Message);
        }

        return quests;
    }

    public List<Level> GetLevels()
    {
        List<Level> levels = new List<Level>();

        string query = "SELECT * FROM level";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Level level = new Level
                {
                    levelId = reader.GetInt32("level_id"),
                    levelName = reader.GetString("level_name"),
                    levelType = reader.GetString("level_type"),
                };
                levels.Add(level);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading levels from database: " + ex.Message);
        }

        return levels;
    }
//    public List<Achievement> GetAchievements()
    
    public List<Boss> GetBosses()
    {
        List<Boss> bosses = new List<Boss>();

        string query = "SELECT * FROM boss";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Boss boss = new Boss
                {
                    bossId = reader.GetInt32("boss_id"),
                    bossName = reader.GetString("boss_name"),
                    abilities = reader.GetString("abilities"),
                    levelId = reader.GetInt32("level_id"),
                };
                bosses.Add(boss);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading boss from database: " + ex.Message);
        }
        return bosses;
    }
    public List<EnemyAI> GetEnemyAIs()
    {
        List<EnemyAI> enemyAIs = new List<EnemyAI>();

        string query = "SELECT * FROM enemy_ai";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                EnemyAI enemyAi = new EnemyAI
                {
                    itemId = reader.GetInt32("item_id"),
                    enemyName = reader.GetString("enemy_name"),
                    health = reader.GetInt32("health"),
                };
                enemyAIs.Add(enemyAi);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading enemy_ais from database: " + ex.Message);
        }

        return enemyAIs;
    }

    public List<GameCharacter> GetGameCharacters()
    {
        List<GameCharacter> gameCharacters = new List<GameCharacter>();

        string query = "SELECT * FROM game_character";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                GameCharacter gameCharacter = new GameCharacter
                {
                    characterId = reader.GetInt32("character_id"),
                    characterName = reader.GetString("character_name"),
                    characterType = reader.GetString("character_type"),
                    characterPrice = reader.GetInt32("character_price"),
                    storeId = reader.GetInt32("store_id"),
             };
             gameCharacters.Add(gameCharacter);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading game Character from database: " + ex.Message);
        }

        return gameCharacters;
    }
    
    public List<Achievement> GetAchievements()
    {
        List<Achievement> achievements = new List<Achievement>();

        string query = "SELECT * FROM achievement";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Achievement achievement = new Achievement
                {
                    achievementId = reader.GetInt32("achievement_id"),
                    achievementName = reader.GetString("achievement_name"),
                    achievementDesc = reader.GetString("achievement_desc"),
                };
                achievements.Add(achievement);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading achievements from database: " + ex.Message);
        }

        return achievements;
    }
}

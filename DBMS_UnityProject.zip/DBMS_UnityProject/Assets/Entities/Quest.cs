[System.Serializable]
public class Quest {
    public int questId;
    public string questName;
    public int reward = 10;
    public string questType;
}
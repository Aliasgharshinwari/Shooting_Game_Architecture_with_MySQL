[System.Serializable]
public class Player
{
    public int playerId;
    public string playerName;
    public int currency;
    public int numberOfKills;
    public int activeQuestId;
    public int selectedCharId;
}

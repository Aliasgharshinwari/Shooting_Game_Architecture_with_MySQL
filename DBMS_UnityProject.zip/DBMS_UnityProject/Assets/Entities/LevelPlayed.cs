[System.Serializable]
public class LevelPlayed {
    public int levelId;
    public int playerId;
    public string timePlayed;
}
[System.Serializable]
public class Checkpoint {
    public int checkpointNo;
}
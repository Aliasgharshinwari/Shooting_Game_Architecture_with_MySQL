[System.Serializable]
public class GameCharacter
{
    public int characterId;
    public string characterName;
    public string characterType;
    public int characterPrice = 100;
    public int storeId;
}
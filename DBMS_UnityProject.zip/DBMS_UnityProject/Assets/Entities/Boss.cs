[System.Serializable]
public class Boss {
    public int bossId;
    public string bossName;
    public string abilities;
    public int levelId;
}
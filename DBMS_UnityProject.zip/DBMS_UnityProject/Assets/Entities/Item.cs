[System.Serializable]
public class Item {
    public int itemId;
    public string itemType;
}
[System.Serializable]
public class EnemyAI {
     public int itemId;
    public string enemyName;
    public int health;
}
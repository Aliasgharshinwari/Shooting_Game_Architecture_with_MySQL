[System.Serializable]
public class LevelItem {
    public int levelId;
    public int itemId;
}
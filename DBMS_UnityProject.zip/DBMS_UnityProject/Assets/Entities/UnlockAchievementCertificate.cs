[System.Serializable]
public class UnlockAchievementCertificate {
    public int playerId;
    public int achievementId;
    public string timeUnlocked;
}
[System.Serializable]
public class Store {
    public int storeId;
}
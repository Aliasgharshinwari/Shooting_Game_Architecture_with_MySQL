[System.Serializable]
public class Level {
    public int levelId;
    public string levelName;
    public string levelType;
}
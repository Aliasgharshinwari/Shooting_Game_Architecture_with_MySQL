[System.Serializable]
public class Weapon {
    public int weaponId;
    public string weaponName;
    public int damage;
    public int storeId;
}
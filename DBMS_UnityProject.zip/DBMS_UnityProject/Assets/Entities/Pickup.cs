[System.Serializable]
public class Pickup {
    public string pickupType;
}
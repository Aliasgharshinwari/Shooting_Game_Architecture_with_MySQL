using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[ExecuteAlways]
public class DatabaseEditorWindow : EditorWindow
{
    private MySQLDatabase database;
    private Vector2 scrollPosition;

    [MenuItem("Window/Database Editor")]
    public static void ShowWindow()
    {
        GetWindow<DatabaseEditorWindow>("Database Editor");
    }

    private void OnEnable()
    {
        // Replace with your actual database connection string
        string connectionString = "Server=localhost;Database=shooting_game;User ID=root;Password=;Pooling=false";
        database = new MySQLDatabase(connectionString);
        database.OpenConnection();
    }

    private void OnDisable()
    {
        if (database != null)
        {
            database.CloseConnection();
        }
    }

    public void OnGUI()
    {
        GUILayout.Label("Database Editor", EditorStyles.boldLabel);

        if (GUILayout.Button("Show Players"))
        {
            List<Player> players = database.GetPlayers();
            EditorGUILayout.LabelField(players[0].playerName);
            if (players != null)
            {
                foreach (Player player in players)
                {
                    EditorGUILayout.LabelField("Player ID: " + player.playerId);
                    EditorGUILayout.LabelField("Player Name: " + player.playerName);
                    EditorGUILayout.LabelField("Currency: " + player.currency);
                    EditorGUILayout.LabelField("Number of Kills: " + player.numberOfKills);
                    EditorGUILayout.LabelField("Active Quest ID: " + player.activeQuestId);
                    EditorGUILayout.LabelField("Selected Character ID: " + player.selectedCharId);
                    Debug.Log(player.playerId);
                }
            }
            else
            {
                EditorGUILayout.LabelField("No players found.");
            }
        }
    }
}

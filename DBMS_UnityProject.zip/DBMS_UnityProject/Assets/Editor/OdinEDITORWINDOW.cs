using Sirenix.OdinInspector.Editor;
using Sirenix.OdinInspector;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using Unity.VisualScripting;
public class SomeWindow : OdinEditorWindow
{
    protected MySQLDatabase database;

	[MenuItem("My Shooting Game/Game Database")]
	private static void OpenWindow()
    {
        GetWindow<SomeWindow>().Show();
    }
	    
    [TabGroup("Players")]
    [ReadOnly]
    public List<Player> players;

    //[TabGroup("Players")]
    //[Button("Add Player")]
    
    //public Player player;
    public void AddPlayer(){
        GetWindow<AddPlayerWindow>().Show();
    }
    
    [TabGroup("Weapons")]
    [ReadOnly]
    public List<Weapon> weapons;
    
    [TabGroup("Levels")]
    [ReadOnly]
    public List<Level> levels;

    [TabGroup("Achievements")]
    [ReadOnly]
    public List<Achievement> achievements;
    [TabGroup("Quests")]
    [ReadOnly]
    public List<Quest> quests;
  
    [TabGroup("Bosses")]
    [ReadOnly]
    public List<Boss> bosses;
  
    [TabGroup("Enemy AI")]
    [ReadOnly]
    public List<EnemyAI> enemyAIs;
  
    [TabGroup("Game Characters")]
    [ReadOnly]
    public List<GameCharacter> gameCharacters;
/*
    [TabGroup("Checkpoints")]
    [ReadOnly]
    public List<Checkpoint> checkpoints;
  
    [TabGroup("Items")]
    [ReadOnly]
    public List<Item> items;
  
    [TabGroup("Pick Ups")]
    [ReadOnly]
    public List<Pickup> pickups;
*/
     void OnEnable(){
        base.OnEnable();
         string connectionString = "Server=localhost;Database=shooting_game;User ID=root;Password=;Pooling=false";
        database = new MySQLDatabase(connectionString);
        database.OpenConnection();
        init();
     }

     void OnDisable(){
        base.OnDisable();
        database.CloseConnection();
     }

     void init(){
         players = database.GetPlayers();
         levels = database.GetLevels();
         weapons = database.GetWeapons();
         quests = database.GetQuests();
         achievements = database.GetAchievements();
         bosses = database.GetBosses();
         enemyAIs = database.GetEnemyAIs();
         gameCharacters = database.GetGameCharacters();
        // checkpoints = database.GetCheckpoints();
    }
}

public class AddPlayerWindow : SomeWindow
{


    public Player player;
    
    //[Button("Add Player")]
    //public Player player;
    public void Add(){
       database.AddPlayer(player);
    }

    
}
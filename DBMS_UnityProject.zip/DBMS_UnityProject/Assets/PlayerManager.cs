/*
using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using UnityEngine;

public class PlayerManager : MySQLDatabase
{
    public PlayerManager(string connectionString) : base(connectionString)
    {
    }

    public List<Player> GetPlayers()
    {
        List<Player> players = new List<Player>();

        string query = "SELECT * FROM player";
        MySqlCommand cmd = new MySqlCommand(query, connection);

        try
        {
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Player player = new Player
                {
                    playerId = reader.GetInt32("player_id"),
                    playerName = reader.GetString("player_name"),
                    currency = reader.GetInt32("currency"),
                    numberOfKills = reader.GetInt32("number_of_kills"),
                    activeQuestId = reader.GetInt32("active_quest_id"),
                    selectedCharId = reader.GetInt32("selected_char_id")
                };
                players.Add(player);
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error reading players from database: " + ex.Message);
        }

        return players;
    }
    
}
*/